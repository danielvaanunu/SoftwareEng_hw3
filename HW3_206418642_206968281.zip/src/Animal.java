public interface Animal {
    /**
     * we created an interface of Animal,
     * that defines the actions every animal
     * in the zoo have to do
     */

    void eat();
    void performance();
}

public interface UpdateAll {
    /**
     * we created an interface that will
     * help us to notify all the zoo observers
     * with a specific message
     * @param message
     */
    void setMessage(String message);
}
